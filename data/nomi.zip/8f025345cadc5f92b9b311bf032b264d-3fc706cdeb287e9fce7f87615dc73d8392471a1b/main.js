

var width = window.innerWidth-40, height = window.innerHeight;


var colorM = d3.scaleOrdinal(d3.schemePaired);
var colorF = d3.scaleOrdinal(d3.schemePaired);


var y = d3.scaleLinear()
.range([height-100, 130])

var x = d3.scaleLinear()
.domain([0, 15])
.range([width*.1, width-width*.1]);


var absolute = true;
var femaleEntries;
var maleEntries;
var currentBoundaries =[0,49];
var currentEntry = maleEntries;
var hoveredDatum;

var area = d3.area()
.x(function(d, i) {return x(i); })
.y0(function(d) {return y(d[1]); })
.y1(function(d) { return y(d[0]); })
.curve(d3.curveCatmullRom.alpha(0.5));


var svg = d3.select("body").append("svg")
.attr("width", width)
.attr("height", height);

// year labels
var ylabels = svg.selectAll("g")
.data(d3.range(1999, 2015))
.enter()
.append("g")
.attr("transform", function(d,i){
	return "translate("+ x(i) + " " +( y.range()[1]-20) +")"
})

ylabels
.append("text")
.attr("class","ylabel")
.text( function(d){return d})
.attr("text-anchor", "middle")

ylabels
.append("line")
.attr("y1", 10)
.attr("y2", y.range()[0] -  y.range()[1])
.attr("stroke", "#ddd")
// axes


svg.on("mousemove", function() {
	if(hoveredDatum) {	
		var d = hoveredDatum;
		var index = Math.floor( ((d3.event.pageX-x.range()[0]) / x.range()[1] ) * 17 );
		var s = "";
		s += "<p class='name'>" + toTitleCase(d.key) + "</p>"
		s += "<p>" + d[index].data[d.key].count +" nel " +d[index].data.year +"</p>";
		 textLabel.style("display", "block").html(s).style("transform", "translate("+(d3.event.pageX +20) + "px , " +d3.event.pageY +"px)");
		}
	})



svg.append("text").attr("class", "title").attr("x", x.range()[0]).attr("y", 60).text("Nomi italiani dal 1999 al 2014")
var textLabel = d3.select("body").append("p").attr("class", "blabel").style("display", "none");

d3.json("data.json",  function(error, data) {

	femaleEntries = data.female;
	maleEntries = data.male;
	currentEntry = maleEntries;
	

	initControls();
	changeViz();

})

function changeViz() {

	var namesToUse = currentEntry.mostUsed.slice(currentBoundaries[0], currentBoundaries[1]);
	var maxCount = 0;


	// namesToUse.forEach(function(d) {
		currentEntry.history.forEach(function(year) {
			var yearTotal = 0;
			var percentages = {};
			namesToUse.forEach(function(d) {
				yearTotal += year[d.name].count;
			});
			namesToUse.forEach(function(d) {
				year[d.name].percent =year[d.name].count/yearTotal;
			});
			// console.log(yearTotal);
		})
	// })

	var stack = d3.stack()
	.keys(namesToUse.map(function(d){
		return d.name;
	}))
	.value(function(d,key) {
		return d[key].percent;
	})
	// .offset( d3.stackOffsetWiggle)
	// .order(d3.stackOrderInsideOut)
	.order(d3.stackOrderAscending)

	var series = stack(currentEntry.history);

	var alldata = [];
	series.forEach(function(year) {
		year.forEach(function(d){
			alldata.push(d[0]);
			alldata.push(d[1])
		})
	})
	y.domain(d3.extent(alldata))


	svg.selectAll("path")
	.data(series)
	.exit()
	.remove();

	svg.selectAll("path")
	.data(series)
	.enter()
	.append("path")
	.on("mouseover", function(d){
		d3.select(this).attr("stroke", "white")
		this.parentNode.appendChild(this);
		hoveredDatum = d;
	})
	.on("mouseout", function(d){
		d3.select(this).attr("stroke", "none")
		hoveredDatum = null;
		textLabel.style("display", "none")
	})


	var cscale=  currentEntry == maleEntries ? colorM : colorF;

	svg.selectAll("path")
	.transition()
	.attr("d", function(d) {
		return area(d)
	})
	.attr("fill", function(d,i) {
		// return cscale(Math.sin(getNameIndex(d.key)*.1)*.5+.5);
		return cscale(getNameIndex(d.key))
		// return cscale(getNameIndex(d.key) / currentEntry.mostUsed.length);
	})
	.style("opacity",.8)
	
	d3.select(".noUi-connect").style("background", cscale(1));


}

function getNameIndex(d) {
	for (var i = 0; i < currentEntry.mostUsed.length; i++) {		
		if((d) == currentEntry.mostUsed[i].name)   return i
	}
return -1;
}

function initControls(){
	var controls = d3.select("#controls");
	var sliderCont = d3.select("#slidercont"); 
	var handlesSlider = sliderCont.append("p")
	var sliderW = sliderCont.append("div").attr("id","slider");
	var slider = sliderW.append("div")

	noUiSlider.create(slider.node(), {
		start: currentBoundaries,
		connect: true,
		range: {
			'min': [  0 ],
			'max': [ 999 ]
		}
	});


	slider.node().noUiSlider.on('update', function( values, handle ) {
		handlesSlider.text("Dal "+(Math.round(values[0])+1) + "° al " +(Math.round(values[1])+1) +"°");
	});

	slider.node().noUiSlider.on('change', function( values, handle ) {
		currentBoundaries = values;
		changeViz();
	});


	var label = d3.select("#gender").selectAll("label")
	.data(["Maschile", "Femminile"])
	.enter().append("label");

	label.append("input")
	.attr("type", "radio")
	.attr("name", "nametype")
	.attr("value", function(d) { return d})
	.on("change", function(d) {
		currentEntry = d == "Maschile" ? maleEntries : femaleEntries; 
		changeViz();
	})
	.property("checked",function(d,i) {
		return i== 0
	})
	// .property("checked", true);
	label.append("span")
	.text(function(d) { return d; });



	// var label = d3.select("#normalized").selectAll("label")
	// .data(["Assoluto", "Relativo"])
	// .enter().append("label");

	// label.append("input")
	// .attr("type", "radio")
	// .attr("name", "datumtype")
	// .attr("value", function(d) { return d})
	// .on("change", function onChange(d) {
	// 	absolute = d == "Assoluto"; 
	// 	changeViz();
	// })
	// .property("checked", true);

	// label.append("span")
	// .text(function(d) { return d; });


}

function toTitleCase(str)
{
	return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
}
