var d3  = require("d3");
var fs = require("fs");

fs.readFile('./data.csv', 'utf8', function (err, data) {

	var data = d3.csvParse(data);
	var mostUsedFemaleNames = [];
	var mostUsedMaleNames = [];
	var femaleEntries;
	var maleEntries;

	
	femaleEntries = d3.nest()
	.key(function(d) { return d.year; })
	.entries(data.filter(function(d) {
		return d.gender == "f";
	}));


	maleEntries = d3.nest()
	.key(function(d) { return d.year; })
	.entries(data.filter(function(d) {
		return d.gender == "m";
	}));

	var maxNames = 1000;
	mostUsedMaleNames = findMostUsedNames(maleEntries).slice(0,maxNames);
	mostUsedFemaleNames = findMostUsedNames(femaleEntries).slice(0,maxNames);

	var obj = {
		
		male: {
			mostUsed: mostUsedMaleNames,
			history: getYears(maleEntries, mostUsedMaleNames)
		},

		female: {
			mostUsed: mostUsedFemaleNames,
			history: getYears(femaleEntries, mostUsedFemaleNames)
		}

	}

	fs.writeFile( "data.json",JSON.stringify(obj));

	function getYears(nameEntries, namesToBeUsed) {
		var history = [];

		nameEntries.forEach(function(d, yearIndex) {

			var year = d.key;
			history[yearIndex] = {year: year};
			var byRank = [];
			for (var k = 0; k < namesToBeUsed.length; k++) {
				var count = 0;
				var currentName = namesToBeUsed[k].name;
				for (var i = 0; i < d.values.length; i++) {
					var name = d.values[i].name;
					if(name == currentName) {
						count =  parseInt(d.values[i].count);
						break;
					}
				}
				history[yearIndex][currentName] = {};
				history[yearIndex][currentName].count = count;
				byRank.push({name:currentName, count:count})
			}

			byRank.sort(function(a,b) {
				return b.count - a.count;
			})

			byRank.forEach(function(d,i) {
				history[yearIndex][d.name].rank = i;
			})


		});

		return history;

	}

	function findMostUsedNames(nameEntries) {

		// find most used names
		var nameCount = {};
		var mostUsedNames = [];

		nameEntries.forEach(function(d) {
			for (var i = 0; i < d.values.length; i++) {
				var name = d.values[i].name;
				if(!nameCount[name]) {
					nameCount[name] = 0;
				}
				var count = parseInt(d.values[i].count);
				nameCount[name] += count;
			}
		});



		for(var i in nameCount) {
			mostUsedNames.push({name:i, count:nameCount[i]});
		}

		mostUsedNames.sort(function(a,b) {
			return b.count - a.count;
		});

		return mostUsedNames;
	}
});